var LoadPhoto= document.getElementById('LoadPhoto')
var Description= document.getElementById('upload')

LoadPhoto.addEventListener('load', verif)


function verif(){

  
    if(!document.getElementById('notification')){

        Newdiv=document.createElement("div");
        Newdiv.setAttribute("id",'notification');           
        Description.appendChild(Newdiv);
   }
   else{
            var notification=document.getElementById('notification')   
            if( LoadPhoto.value.length>0){

                console.log('testif')
                notification.className="alert alert-success";
                notification.innerHTML="Vous pouvez ajouter la photo ";
                document.getElementById('addPhoto').removeAttribute("disabled")

            }
            else{

                notification.className="alert alert-danger";
                notification.innerHTML="Vueillez charger le champ avec u";
                document.getElementById('addPhoto').setAttribute("disabled","");
                console.log('else1')

            }
            

        }


}

