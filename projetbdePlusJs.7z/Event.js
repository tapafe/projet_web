
var InputEventName= document.getElementById('InputEventName') 
var InputPhoto= document.getElementById('InputPhoto')
var InputDate= document.getElementById('InputDate')
var InputDescription = document.getElementById('descriptionEvent')
var Description = document.getElementById('description')
var InputEventFreq = document.getElementById('Event1')
var InputEventFreq2= document.getElementById('Event2')


InputEventName.addEventListener('keyup',verif)
InputPhoto.addEventListener('load', verif)
InputDate.addEventListener('keyup', verif)
InputDescription.addEventListener('keyup', verif)
InputEventFreq.addEventListener('click',verif)
InputEventFreq2.addEventListener('click',verif) 

function verif(){

  
    if(!document.getElementById('notification')){

        Newdiv=document.createElement("div");
        Newdiv.setAttribute("id",'notification');           
        Description.appendChild(Newdiv);
   }
   else{
            var notification=document.getElementById('notification')   
            if( InputEventName.value.length>0 && InputPhoto.value.length>0 && InputDate.value.length>0 && InputDescription.value.length>10){

                console.log('testif')
                notification.className="alert alert-success";
                notification.innerHTML="Vous pouvez ajouter un evenement";
                document.getElementById('BtnAddEvent').removeAttribute("disabled")

            }
            else{

                notification.className="alert alert-danger";
                notification.innerHTML="Vous avez une erreur dans les champs saisis";
                document.getElementById('BtnAddEvent').setAttribute("disabled","");
                console.log('else1')

            }
            

        }


}