
var InputName= document.getElementById('InputName') 
var InputPhoto= document.getElementById('InputPhoto')
var InputDescription = document.getElementById('descriptionBAI')
var Description = document.getElementById('description')


InputName.addEventListener('keyup',verif)
InputPhoto.addEventListener('load', verif)
InputDescription.addEventListener('keyup', verif)


function verif(){

  
    if(!document.getElementById('notification')){

        Newdiv=document.createElement("div");
        Newdiv.setAttribute("id",'notification');           
        Description.appendChild(Newdiv);
   }
   else{
            var notification=document.getElementById('notification')   

            if( InputName.value.length>0 && InputPhoto.value.length>0 && InputDescription.value.length<10){

                console.log('testif')
                notification.className="alert alert-success";
                notification.innerHTML="Vous pouvez ajouter une idée";
                document.getElementById('addidee').removeAttribute("disabled")

            }
            else{

                notification.className="alert alert-danger";
                notification.innerHTML="Vous avez une erreur dans les champs saisis";
                document.getElementById('addidee').setAttribute("disabled","");
                console.log('else1')

            }
            

        }


}