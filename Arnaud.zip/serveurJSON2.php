<?php

header("Content-Type: application/json");
Require_once("BDD.php");
$code = $_POST["code"];

$rq = singleton::getInstance()->prepare("SELECT * FROM `utilisateurs` WHERE ID_Utilisateurs = '$code';");
$rq->execute();

echo json_encode($rq->fetchAll());

?>