var getJSON = function(url, callback){

    let xhr = new XMLHttpRequest();
    xhr.open('POST', url, true);

    xhr.responseType = 'json';

    xhr.setRequestHeader("Content-Type", "application/json");

    xhr.onload = function(){
        if(xhr.status === 200){
            console.log("200");
            callback(null, xhr.response);
            console
        }
        else {
            callback(xhr.status, xhr.response);
        }
    };
    xhr.send();
}

var passagePHP = function() {
    let pseudo = document.getElementById('name').value;
    getJSON('http://projet/scriptInscription.php', traitement);
}

var traitement = function(err,data){
    console.log(data);
}

document.getElementById("btn").addEventListener("click",passagePHP);