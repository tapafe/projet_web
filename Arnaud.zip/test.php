<!DOCTYPE html>
<html>
<head>
	<title>test</title>
    <script src="ajaxJSON.js"></script>
</head>
<body>
	<div id="resultat"></div>

    <table id="table">

    </table>

    <script> ajaxJSON() </script>
</body>
</html>