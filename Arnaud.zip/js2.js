<script type="text/javascript">
function ajaxJSON(){
    var resultat = document.getElementByID("resultat");
    xhr = new XMLHttpRequest();
    xhr.open("GET", "voiture.json", true);
    xhr.setRequestHeader("Content-type", "application/json");

    xhr.onreadystatechange = function () {
        if(xhr.readyState == 4 && xhr.status == 200){
            var donneesJSON = JSON.parse(xhr.responseText);
            resultat.innerHTML = "";

            for (var objet in donneesJSON){
                resultat.innerHTML += donneesJSON[objet].libelle + " -> ";
            }
        }
    }
    xhr.send(null);
    resultat.innerHTML = "Attente"
}
</script>