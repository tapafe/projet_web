function ajaxJSON(){
    var resultat = document.getElementById("resultat");
    xhr = new XMLHttpRequest();
    xhr.open("GET", "nameJSON.php", true);
    xhr.setRequestHeader("Content-type", "application/json");
    var trinc = 0;
    var tdinc = 0;
    xhr.onreadystatechange = function () {
        if(xhr.readyState == 4 && xhr.status == 200){
            console.log(xhr.responseText);
            var donneesJSON = JSON.parse(xhr.responseText);
            resultat.innerHTML = "";

            for (var objet in donneesJSON){

                var tr_to_insert ;
                var tr_container_block ;

                var td_to_insert;
                var td_container_block;

                tr_to_insert = document.createElement( 'tr' );
                tr_to_insert.id = 'tr' + trinc;

                tr_container_block = document.getElementById( 'table' );
                tr_container_block.appendChild( tr_to_insert);


                td_to_insert = document.createElement( 'td' );
                td_to_insert.className = 'td' + tdinc;
                td_to_insert.style = 'border: 1px solid black';

                td_container_block = document.getElementById('tr' + trinc);
                td_container_block.appendChild(td_to_insert);
                td_to_insert.innerHTML = donneesJSON[objet].Nom + " " //date get on DataBase


                td_to_insert = document.createElement( 'td' );
                td_to_insert.className = 'td' + tdinc;
                td_to_insert.style = 'border: 1px solid black';

                td_container_block = document.getElementById('tr' + trinc);
                td_container_block.appendChild(td_to_insert);
                td_to_insert.innerHTML = donneesJSON[objet].Prenom + " " //date get on DataBase


                trinc = trinc + 1;
                //tdinc = tdinc + 1;
            }
        }
    }
    xhr.send(null);
    resultat.innerHTML = "Attente"
}