<!DOCTYPE html>
<html>
<head>
    <title>test</title>
    <script src="ajaxJSON2.js"></script>
</head>
<body>

    

    <form id="form" name="formulaire">

        Id utilisateur:
        <select id="liste" onchange="controlerChoixListe(document.getElementById('liste'), 'Choisir')">
            <option value="CODE" selected>  Code utilisateur </option>
            <option value="1"> U001</option>
            <option value="2"> U002</option>
            <option value="3"> U003</option>
            <option value="4"> U004</option>
        </select>
        
    <div id="resultat"></div>

    </form>

    <script>
        function controlerChoixListe(liste, messageAlerte) {
            if (liste.value == "CODE"){
                alert(messageAlerte);
                liste.focus();
                return false;
            } else {
                ajaxJSON2();
                return true;
            }

        }

    </script>
</body>
</html>