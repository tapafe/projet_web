<?php
Require_once("BDD.php");

if(isset($_POST['Nom']) && isset($_POST['Prenom']) && isset($_POST['Mail']) && isset($_POST['Mot_De_Passe'])){

	$Nom = $_POST['Nom'];
	$Prenom = $_POST['Prenom'];
	$Mail = $_POST['Mail'];
	$Mdp = $_POST['Mot_De_Passe'];

	$rq = singleton::getInstance()->prepare('CALL inscription_utilisateurs(:Nom, :Prenom, :Mail, :Mdp)');
	$rq->execute(array(':Nom'=>$Nom, ':Prenom'=>$Prenom, ':Mail'=>$Mail, ':Mdp'=>$Mdp));

	header("Location: xhr.php");
	exit;
}


if(isset($_POST['Nom'])){
	$resp = singleton::getInstance()->prepare('SELECT * FROM `utilisateurs`');
	$resp->execute;
	echo json_encode($resp->fetchall());

	header("Location: xhr.php");
	exit;
}

?>

