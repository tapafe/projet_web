<?php
  require_once 'singleton.php';
  singleton::setConfig('mysql:host=localhost;dbname=projet_web;charset=utf8', 'root', '');
?>
