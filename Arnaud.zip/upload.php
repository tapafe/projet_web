<?php

    Require_once("BDD.php");

    if (isset($_FILES['avatar'])){
        $dossier = 'upload/';
        $fichier = basename($_FILES['avatar']['name']);
        if (move_uploaded_file($_FILES['avatar']['tmp_name'], $dossier . $fichier)){
            echo 'Le fichier peut etre upload. ';
        }else{
            echo 'Le fichier ne peut pas etre upload. ';
        }
    }

    $adresse = 'upload/' . $_FILES['avatar']['name'];
    $verif = singleton::getInstance()->prepare('SELECT * FROM Photo WHERE Photo.Texte_Photo = :adresse');
    $verif->execute(array(':adresse'=>$adresse));
    if ($verif->rowCount() == 0){
        $rq = singleton::getInstance()->prepare('INSERT INTO Photo(Texte_Photo) VALUES(:adresse)');
        $rq->execute(array(':adresse'=>$adresse));
    }else{
        echo "La photo porte le meme nom qu'une autre. Elle ne sera pas upload";
    }

?>