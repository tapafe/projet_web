<?php

header("Content-Type: application/json");
Require_once("BDD.php");
$code = $_POST["code"];

$rq = singleton::getInstance()->prepare("CALL Add_occurent()");
$rq->execute();

echo json_encode($rq->fetchAll());

?>