<?php
// Version d'encodage du mail
$header = "MIME-Version: 1.0\r\n";

$header .='From:"Arnaud"<rigaut147@gmail.com>';
$header .='Content-Type:text/html; charset="uft-8"'."\n";
$header .='Contetnt-Transfer-Encoding: 8bit';

// Le message
$message = "
<html>
    <body>
        Mail
    </body>
</html>
";

// Envoi du mail
    mail('araud.rigaut@gmail.com', 'Mon Sujet', $message, $header);


?>