<?php
Require_once("BDD.php");
session_start();

if(isset($_POST['Mot_De_Passe']) && isset($_POST['Mail'])){

	$Mail = $_POST['Maillogin'];
    $Mdp = $_POST['passwordlogin'];

	$rq = singleton::getInstance()->prepare('CALL login(:Mail, :Mdp)');
	$rq->execute(array(':Mail'=>$Mail, ':Mdp'=>$Mdp));

	$result = $rq->fetchall();        
    $_SESSION['login'] = $result[0]['Maillogin'];
	
	header("Location: xhr.php");
	exit;
}

?>