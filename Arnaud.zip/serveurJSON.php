<?php

    header("Content-Type: application/json");
    Require_once("BDD.php");

    $rq = singleton::getInstance()->prepare("SELECT * FROM `utilisateurs`");
    $rq->execute();

        echo json_encode($rq->fetchAll());

?>