<?php
Require_once("BDD.php");

	$rq = singleton::getInstance()->prepare("select * from `utilisateurs`");
	$rq->execute();

	$resultrq = $rq->fetchall();

	for($i=0; $i<$rq->rowCount();$i++){
		echo $resultrq[$i]['Nom'] . " ";
	}
?>