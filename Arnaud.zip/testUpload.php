<!DOCTYPE html>
<html>
<body>

<form method="post" action="upload.php" enctype="multipart/form-data">
    <input type="hidden" name="MAX_FILE_SIZE" value="100000">
    Fichier : <input type="file" name="avatar">
    <input type="submit" name="envoyer" value="Envoyer le fichier">
</form>


</body>
</html>