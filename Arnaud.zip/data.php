<?php
Require_once("BDD.php");

$scriptData = array(
		'Articles' => 200
	);

?>