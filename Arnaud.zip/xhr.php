<?php
Require_once("BDD.php");
session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title>Test</title>

</head>
<body>
			<div id="login">
			<form method="post" action="scriptConnexion.php" autocomplete="on">
				<h1>Connexion</h1> 
				<p> 
					<label>Mail : </label>
					<input id="Maillogin" name="Mail" required="required" type="required" placeholder="Mail"/>
				</p>
				<p> 
					<label>Mot de passe : </label>
					<input id="passwordlogin" name="Mot_De_Passe" required="required" type="password" placeholder="Mot de passe">
				</p>

				<p> 
					<input type="submit" value="Connexion" /> 
				</p>
			</form>
		</div>


		<div id="register">
			<form  method="post" action="scriptInscription.php" autocomplete="on"> 
				<h1> Inscription </h1> 
				<p> 
					<label>Nom : </label>
					<input id="name" name="Nom" required="required" type="text" placeholder="Nom" />
				</p>

				<p> 
					<label>Prenom : </label>
					<input id="firstname" name="Prenom" required="required" type="required" placeholder="Prenom"/>
				</p>

				<p> 
					<label>Mot de passe : </label>
					<input id="password" name="Mot_De_Passe" required="required" type="password" placeholder="Mot de passe"/>
				</p>

				<p> 
					<label>Mail : </label>
					<input id="Mail" name="Mail" required="required" type="required" placeholder="Mail"/>
				</p>

				<p class="signin button"> 
					<input id="signinButton" type="submit" value="S'inscrire"/> 
				</p>
			</form>
		</div>
	</section>

</body>

</html>