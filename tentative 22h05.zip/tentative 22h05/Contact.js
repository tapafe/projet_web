var InputSurname=document.getElementById('InputSurname')
var InputName=document.getElementById('InputName')
var EmailValue=document.getElementById('InputEmail')
var Localisation=document.getElementById('DivMessage')
var Message=document.getElementById('message')
var EmailRegex= new RegExp("[a-z]+\.{1}[a-z]+@(viacesi.fr|cesi.fr)")


InputName.addEventListener('keyup', verif)
InputSurname.addEventListener('keyup', verif)
EmailValue.addEventListener('keyup',verif)
Message.addEventListener('keyup',verif)


function verif(){

   
      
   
    if(!document.getElementById('notification')){

        Newdiv=document.createElement("div");
        Newdiv.setAttribute("id",'notification');           
        Localisation.appendChild(Newdiv);


   }

   else{
   
    var notification=document.getElementById('notification')

   
       if( EmailRegex.test(EmailValue.value)==true && InputName.value.length>2 && InputSurname.value.length>0 && Message.value.length>10  ){

        console.log('testif')
           notification.className="alert alert-success";
           notification.innerHTML="Merci du message";
           document.getElementById('BtnSend').removeAttribute("disabled")
       }
       else{
        
           notification.className="alert alert-danger";
           notification.innerHTML="Vous avez une erreur dans les champs saisis";
           document.getElementById('BtnSend').setAttribute("disabled","");
           console.log('else1')
       }

   }

}

