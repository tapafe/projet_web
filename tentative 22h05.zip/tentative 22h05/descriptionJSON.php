<?php

header("Content-Type: application/json");
Require_once("BDD.php");

$rq2 = singleton::getInstance()->prepare("SELECT * FROM `description`");
$rq2->execute();

echo json_encode($rq2->fetchAll());

?>