var EmailValue=document.getElementById('InputEmail')
var NameDiv=document.getElementById('name1')
var PasswordInput=document.getElementById('InputPassword')
var PasswordConf=document.getElementById('InputconfPassword')
var InputSurname=document.getElementById('Inputsurname')
var InputName=document.getElementById('Inputname')


var EmailRegex= new RegExp("[a-z]+\.{1}[a-z]+@(viacesi.fr|cesi.fr)")
var PasswordRegex= new RegExp("^(?=.*[A-Z])(?=.*[0-9])(?=.{2,})")








var Email=function(){

    
        
   
   if(!document.getElementById('notification')){

       Newdiv=document.createElement("div");
       Newdiv.setAttribute("id",'notification');           
       NameDiv.appendChild(Newdiv);
      
   
   }

   else{
   
    var notification=document.getElementById('notification')

   
   
       if( EmailRegex.test(EmailValue.value)==true && PasswordRegex.test(PasswordInput.value)==true && PasswordInput.value==PasswordConf.value ){
            
        console.log('testif')
           notification.className="alert alert-success form-group";
           notification.innerHTML="Les parties mail et authentification sont valides"   
           document.getElementById('Btninscription').setAttribute("disabled","");
    
           
           return 1;
          
       }

    
       else{
        
           notification.className="alert alert-danger form-group";
           notification.innerHTML="Votre email ou votre mot de passe ne sont pas valides ";
           document.getElementById('Btninscription').setAttribute("disabled","");

          
         
            
       }

       


   }
}

var Name1=function (){



    if(!document.getElementById('notification')){

        Newdiv=document.createElement("div");
        Newdiv.setAttribute("id",'notification');           
        NameDiv.appendChild(Newdiv);
       
 
    }

    else{
        var notification=document.getElementById('notification')

   
   
        if(InputSurname.value.length>2 && InputName.value.length>2 ){
             
         console.log('testif')
                   
         
             document.getElementById('Btninscription').removeAttribute("disabled")

            notification.className="alert alert-success form-group";
            notification.innerHTML=" Votre inscription est valide";

    
            
        }
 
     
        else{
         
            notification.className="alert alert-warning form-group";
            notification.innerHTML=" Completer avec votre identité";
            document.getElementById('Btninscription').setAttribute("disabled","");

            
          
            
        }
 

    }
}




EmailValue.addEventListener('keyup',Email)
PasswordInput.addEventListener('keyup',Email)
PasswordConf.addEventListener('keyup',Email)
InputSurname.addEventListener('keyup',Name1)
InputName.addEventListener('keyup',Name1)


//TODO: deblocage du boutton si les deux cond sont verifs 

  

  


