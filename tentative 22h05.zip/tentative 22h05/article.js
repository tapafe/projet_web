function boutique() {
    var resultat = document.getElementById("articles");

    while (resultat.firstChild) {
        resultat.removeChild(resultat.firstChild);
    }



    xhr = new XMLHttpRequest();
    xhr.open("POST", "boutique.php", true);

    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {

            //console.log(xhr.responseText);
            var donneesJSON = JSON.parse(xhr.responseText);
            for (var article in donneesJSON) {
                resultat.insertAdjacentHTML('beforeend', "<div class=\"col-md-4\">\n" +
                    "            <div class=\"card mb-4 box-shadow zoomArticle\">\n" +
                    "              <img class=\"card-img-top topvente\" data-src=\"..\" alt=\"article [100%x225]\" src=\"..\" data-holder-rendered=\"true\">\n" +
                    "              <div class=\"card-body\">\n" +
                    "                \n" +
                    "                <H5 class=\"card-text\">"+ donneesJSON[article].name_products +" <span class=\"badge badge-success\">En stock</span></H5>\n" +
                    "          <p class=\"card-text\">"+ donneesJSON[article].Description_Products +"</p>\n" +
                    "                \n" +
                    "          <p>Prix : "+ donneesJSON[article].price_products +"</p>\n" +
                    "                <div class=\"d-flex justify-content-between align-items-center\">\n" +
                    "                  <div class=\"btn-group\">\n" +
                    "                    <button type=\"button\" class=\"btn btn-sm btn-primary\">Acheter</button>\n" +
                    "                    <button type=\"button\" class=\"btn btn-sm btn-danger\">Suppression</button>\n" +
                    "                  </div>\n" +
                    "                 \n" +
                    "                </div>\n" +
                    "              </div>\n" +
                    "            </div>\n" +
                    "          </div>");
            }
        }
    }


    var code = 'post=';
    code += document.getElementById('sort').value;

    xhr.send(code);
    //console.log(code);

}