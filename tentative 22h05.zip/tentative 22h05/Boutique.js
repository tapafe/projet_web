
var InputArticleName= document.getElementById('InputNameArticle') 
var InputPhoto= document.getElementById('InputPhoto')
var Description= document.getElementById('description')
var InputDescription =  document.getElementById('Inputdescription')
var InputPrice =  document.getElementById('price')

InputArticleName.addEventListener('keyup',verif)
InputPhoto.addEventListener('load', verif)
InputDescription.addEventListener('keyup', verif)
InputPrice.addEventListener('keyup', verif)

function verif(){

  
    if(!document.getElementById('notification')){

        Newdiv=document.createElement("div");
        Newdiv.setAttribute("id",'notification');           
        Description.appendChild(Newdiv);
   }
   else{
            var notification=document.getElementById('notification')   
            if( InputArticleName.value.length>0 && InputPhoto.value.length>0 && InputPrice.value.length>0 && InputDescription.value.length>10){

                console.log('testif')
                notification.className="alert alert-success";
                notification.innerHTML="Vous pouvez ajouter un produit";
                document.getElementById('addarticle').removeAttribute("disabled")

            }
            else{

                notification.className="alert alert-danger";
                notification.innerHTML="Vous avez une erreur dans les champs saisis";
                document.getElementById('addarticle').setAttribute("disabled","");
                console.log('else1')

            }
            

        }


}

