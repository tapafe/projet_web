function ajoutEvenement() {
        xhr = new XMLHttpRequest();
    xhr.open("POST", "serveurJSON2.php", true);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

    var parametre = 'code=';
    parametre += document.getElementById('liste').value;

    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            console.log(xhr.responseText);
            var donneesJSON = JSON.parse(xhr.responseText);
            resultat.innerHTML = "";

            for (var objet in donneesJSON) {

                var block_to_insert ;
                var container_block ;

                block_to_insert = document.createElement( 'div' );
                block_to_insert.id = 'div' + divinc;

                block_to_insert.innerHTML = donneesJSON[objet].Nom + " ";

                container_block = document.getElementById( 'form' );
                container_block.appendChild( block_to_insert);
            }
        }
    }



    xhr.send(parametre);
    resultat.innerHTML = "Attente"
}
