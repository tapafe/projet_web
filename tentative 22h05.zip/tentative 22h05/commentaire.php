<?php

header("Content-Type: application/json");
Require_once("BDD.php");

$rq = singleton::getInstance()->prepare("CALL display_occurent_comment");
$rq->execute();
echo json_encode($rq->fetchAll());
?>