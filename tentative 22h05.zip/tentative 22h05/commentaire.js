function ajoutCommentaire() {
    var resultat = document.getElementById("navbot");

    xhr2 = new XMLHttpRequest();
    xhr2.open("GET", "commentaire.php", true);
    xhr2.setRequestHeader("Content-type", "application/json");
    xhr2.onreadystatechange = function () {
        if (xhr2.readyState == 4 && xhr2.status == 200) {
            console.log(xhr2.responseText);
            var donneesJSON = JSON.parse(xhr2.responseText);

            for (var objet in donneesJSON) {

                resultat.insertAdjacentHTML('beforeend', "<div class=\"modal fade\" id=\"photoEvent"+ donneesJSON[objet].ID_Occurent +"\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"LabelEvent\" aria-hidden=\"true\">\n" +
                    "                <div class=\"modal-dialog modal-dialog-centered modal-lg\" role=\"document\">\n" +
                    "                    <div class=\"modal-content\">\n" +
                    "\n" +
                    "                        <div class=\"modal-header\">\n" +
                    "                            <h5 class=\"modal-title\" id=\"LabelEvent\">"+ donneesJSON[objet].Name_Occurent +"</h5>\n" +
                    "                            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"></button>\n" +
                    "                            <span aria-hidden=\"true\">&times;</span>\n" +
                    "                            </button>\n" +
                    "                        </div>\n" +
                    "                        <div id=\"commentpos\" class=\"modal-body row\">\n" +
                    "\n" +
                    "                            <div class=\"col-md-6\">\n" +
                    "                                <div class=\"card mb-4 box-shadow\">\n" +
                    "                                    <img class=\"card-img-top imgpopup\" src= "+ donneesJSON[objet].Name_Pictures +" alt=\"photo event\" >\n" +
                    "                                    <div class=\"card-body\">\n" +
                    "\n" +
                    "\n" +
                    "                                        <div class=\"row \">\n" +
                    "                                            <button type=\"button\" id=\"jaime\"  class=\"btn btn-sm btn-outline-secondary\"><i class=\"far fa-heart\"></i></button>\n" +
                    "                                            <div class=\"btn-group\">\n" +
                    "                                                <button type=\"button\" id=\"commentaire\" class=\"btn btn-sm btn-outline-secondary\" style=\"margin-left:5px;\"><i class=\"far fa-comments\"></i></button>\n" +
                    "                                                <textarea type=\"text\" id=\"textCommentaire\" class=\"form-control\" placeholder=\"Commentez..\" rows=\"1\" ></textarea>\n" +
                    "                                            </div>\n" +
                    "                                        </div>\n" +
                    "\n" +
                    "                                        <div class=\"card text-black bg-light sm-2\" style=\"max-width: 18rem; margin-top:10px\">\n" +
                    "                                            <div class=\"card-header\">Nom utilisateur:</div>\n" +
                    "                                            <div class=\"card-body\">\n" +
                    "                                                <p id=\"commentairepopup\" class=\"card-text\"> "+ donneesJSON[objet].Text_Picture_Comment +" </p>\n" +
                    "                                            </div>\n" +
                    "                                        </div>\n" +
                    "                                    </div>\n" +
                    "                                </div>\n" +
                    "                            </div>\n" +
                    "\n" +
                    "\n" +
                    "                        </div>\n" +
                    "\n" +
                    "\n" +
                    "                    </div>\n" +
                    "                </div>\n" +
                    "            </div>");

            }
        }
    }
    xhr2.send(null);
}