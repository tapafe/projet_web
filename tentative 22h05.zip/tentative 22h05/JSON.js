function ajoutEventJSON() {
    var resultat = document.getElementById("navbot");
    var descinc = 0;

    xhr = new XMLHttpRequest();
    xhr.open("GET", "nameJSON.php", true);
    xhr.setRequestHeader("Content-type", "application/json");
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            //console.log(xhr.responseText);
            var donneesJSON = JSON.parse(xhr.responseText);

            for (var objet in donneesJSON) {

                resultat.insertAdjacentHTML('beforebegin', "<div  class=\"container idees\" style=\"margin-top:30px\">\n" +
                    "    <hr class=\"featurette-divider\">\n" +
                    "    <div id=\"nom" + donneesJSON[objet].Name_Occurent + "\" class=\"row featurette idees\">\n" +
                    "\n" +
                    "        <div class=\"col-md-3 offset-1 offset-xs-0\">\n" +
                    "            <img class=\"featurette-image img-fluid mx-auto\" data-src=\"holder.js/500x500/auto\" alt=\"image de l'idée\" style=\"width:250px; height:250px\" src= "+ donneesJSON[objet].Text_Pictures +">\n" +
                    "        </div>\n" +
                    "        <div class=\"col-md-7\">\n" +
                    "            <h2 id=\"nomdelidee\" class=\"featurette-heading\">" + donneesJSON[objet].Name_Occurent + " " + "</h2>\n" +
                    "            <p id=\"description0\" "+ descinc +" class=\"lead\">Description: " + donneesJSON[objet].Text_Description + " " + "</p>\n" +
                    "\n" +
                    "            <a href=\"#like\"><i class=\"far fa-heart\"></i></a>\n" +
                    "<button type=\"button\" class=\"btn btn-outline-secondary btn-sm\" data-toggle=\"modal\" data-target=\"#photoEvent" + donneesJSON[objet].ID_Occurent+"\">\n" +
                    "                Afficher les photos\n" +
                    "            </button>\n" +
                    "\n" +
                    "            <button type=\"button\" class=\"btn btn-outline-secondary btn-sm\" data-toggle=\"modal\" data-target=\"#Ajoutphoto\" >\n" +
                    "                Ajouter une photo\n" +
                    "<button type=\"button\" class=\"btn btn-outline-primary btn-sm\" data-toggle=\"modal\"  >\n" +
                    "                Telecharger les photos\n" +
                    "              </button>\n" +
                    "              <button type=\"button\" class=\"btn btn-outline-danger btn-sm\" data-toggle=\"modal\">\n" +
                    "                Signaler\n" +
                    "              </button>"+
                    "            </button>" +
                    "        </div>\n" +
                    "    </div>\n" +
                    "</div>");

            }
        }
    }
    xhr.send(null);
}