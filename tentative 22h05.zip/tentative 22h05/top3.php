<?php

header("Content-Type: application/json");
Require_once("BDD.php");
$rq = singleton::getInstance()->prepare("CALL display_best_articles()");
$rq->execute();
echo json_encode($rq->fetchAll());
?>