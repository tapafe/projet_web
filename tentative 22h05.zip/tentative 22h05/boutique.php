<?php
Require_once("BDD.php");
header("Content-Type: application/json");


$code = $_POST["post"];

if ($code == "ASC"){
    $rq = singleton::getInstance()->prepare("CALL sort_by_price_rising;");
    $rq->execute();
}else{
    $rq = singleton::getInstance()->prepare("CALL sort_by_price_descending;");
    $rq->execute();
}
    echo json_encode($rq->fetchAll());
?>