function top3() {
    var resultat = document.getElementById("top3");

    xhr2 = new XMLHttpRequest();
    xhr2.open("GET", "top3.php", true);
    xhr2.setRequestHeader("Content-type", "application/json");
    xhr2.onreadystatechange = function () {
        if (xhr2.readyState == 4 && xhr2.status == 200) {
            //console.log(xhr2.responseText);
            var donneesJSON = JSON.parse(xhr2.responseText);

            for (var top3 in donneesJSON) {

                resultat.insertAdjacentHTML('beforeend', "<div class=\"col-md-4\">\n" +
                    "            <div class=\"card mb-4 box-shadow zoomArticle\">\n" +
                    "              <img class=\"card-img-top topvente\" data-src=\"..\" alt=\"article [100%x225]\" src=\"..\" data-holder-rendered=\"true\">\n" +
                    "              <div class=\"card-body\">\n" +
                    "                \n" +
                    "                <H5 class=\"card-text\">"+ donneesJSON[top3].Name_Products +" <span class=\"badge badge-success\">En stock</span></H5>\n" +
                    "          <p class=\"card-text\">"+ donneesJSON[top3].Description_Products +"</p>\n" +
                    "                \n" +
                    "          <p>Prix : "+ donneesJSON[top3].Price_Products +"</p>\n" +
                    "                <div class=\"d-flex justify-content-between align-items-center\">\n" +
                    "                  <div class=\"btn-group\">\n" +
                    "                    <button type=\"button\" class=\"btn btn-sm btn-primary\">Acheter</button>\n" +
                    "                    <button type=\"button\" class=\"btn btn-sm btn-danger\">Suppression</button>\n" +
                    "                  </div>\n" +
                    "                 \n" +
                    "                </div>\n" +
                    "              </div>\n" +
                    "            </div>\n" +
                    "          </div>");

            }
        }
    }
    xhr2.send(null);
}